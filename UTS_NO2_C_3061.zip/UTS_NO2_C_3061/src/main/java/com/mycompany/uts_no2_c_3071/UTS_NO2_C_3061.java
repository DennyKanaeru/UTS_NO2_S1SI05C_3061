/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.uts_no2_c_3061;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author lenovo
 */
public class UTS_NO2_C_3061 {

    public static void main(String[] args) {
        SalariedEmployee_3061 se_3061 = new SalariedEmployee_3061();
        CommissionEmployee_3061 ce_3061 = new CommissionEmployee_3061();
        ProjectPlanner_3061 pp_3061 = new ProjectPlanner_3061();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));        
        try{
            System.out.println("Data Pegawai");
            System.out.print("Nama: ");
            se_3061.Nama_3061 = br.readLine();
            System.out.print("NIP: ");
            se_3061.NIP_3061 = br.readLine();
            System.out.print("Gaji Pokok: ");
            se_3061.GajiPokok_3061 = Float.parseFloat(br.readLine());
            se_3061.TampilData_3061();
            
            System.out.print("Nama: ");
            ce_3061.Nama_3061 = br.readLine();
            System.out.print("NIP: ");
            ce_3061.NIP_3061 = br.readLine();
            System.out.print("GajiPokok: ");
            ce_3061.GajiPokok_3061 = Float.parseFloat(br.readLine());
            System.out.print("Komisi: ");
            ce_3061.Komisi_3061 = Float.parseFloat(br.readLine());
            System.out.print("Total Penjualan: ");
            ce_3061.TotalPenjualan_3061 = Float.parseFloat(br.readLine());
            ce_3061.TotalGaji_3061();
            ce_3061.TampilData_3061();
            
            System.out.print("Nama: ");
            pp_3061.Nama_3061 = br.readLine();
            System.out.print("NIP: ");
            pp_3061.NIP_3061 = br.readLine();
            System.out.print("Gaji Pokok: ");
            pp_3061.GajiPokok_3061 = Float.parseFloat(br.readLine());
            System.out.print("Komisi: ");
            pp_3061.Komisi_3061 = Float.parseFloat(br.readLine());
            System.out.print("Total Hasil Proyek: ");
            pp_3061.TotalHslProyek_3061 = Float.parseFloat(br.readLine());
            pp_3061.TotalGaji_3061();
            pp_3061.TampilData_3061();
        }catch(Exception ex){
            System.out.println(ex);
        }
    }
}
