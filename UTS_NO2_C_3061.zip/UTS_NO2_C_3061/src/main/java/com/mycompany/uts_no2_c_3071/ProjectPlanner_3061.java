/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no2_c_3061;

/**
 *
 * @author lenovo
 */
public class ProjectPlanner_3061 extends Employess_3061{
    public float Komisi_3061;
    public float TotalHslProyek_3061;
    public double Totalgaji_3061;
    
    public ProjectPlanner_3061(){
        
    }
            
    public double TotalGaji_3061(){
        Totalgaji_3061 = GajiPokok_3061 + (Komisi_3061 * TotalHslProyek_3061) - (GajiPokok_3061 *5/100);
        return Totalgaji_3061;
    }
    
    public void TampilData_3061(){
        System.out.println("Project Plannner");
        Tampil_3061();
        System.out.println("Total Gaji: " + Totalgaji_3061);
    }
}
