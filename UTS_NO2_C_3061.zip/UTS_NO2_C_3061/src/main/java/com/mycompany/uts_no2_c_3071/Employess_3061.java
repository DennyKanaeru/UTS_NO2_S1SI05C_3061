/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no2_c_3061;

/**
 *
 * @author lenovo
 */
public class Employess_3061{
    
    protected String Nama_3061;
    protected String NIP_3061;
    protected float GajiPokok_3061;
    
    public void Tampil_0361(){
        System.out.println("Nama: " + Nama_0361);
        System.out.println("NIP: " + NIP_0361);
        System.out.println("Gaji Pokok: " + GajiPokok_0361);
    }
}
