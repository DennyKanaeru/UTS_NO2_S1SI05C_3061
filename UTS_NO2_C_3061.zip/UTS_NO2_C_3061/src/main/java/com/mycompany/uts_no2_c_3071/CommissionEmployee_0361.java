/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no2_c_0361;

/**
 *
 * @author lenovo
 */
public class CommissionEmployee_0361 extends Employess_3071{
    public float Komisi_0361;
    public float TotalPenjualan_0361;
    public float Totalgaji_0361;
    
    public CommissionEmployee_0361(){
        
    }
    
    public float TotalGaji_0361(){
        Totalgaji_0361 = GajiPokok_0361 + (Komisi_0361 * TotalPenjualan_0361);
        return Totalgaji_0361;
    }
    
    public void TampilData_0361(){
        System.out.println("Commission Employee");
        Tampil_0361();
        System.out.println("Total Gaji: " + Totalgaji_0361);
    }
}
