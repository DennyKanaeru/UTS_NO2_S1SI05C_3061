/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_no2_c_3061;

/**
 *
 * @author badnoby
 */
public class SalariedEmployee_3061 extends Employess_3061 {
    public SalariedEmployee_3061(){
        
    }
    
    public void TampilData_3061(){
        System.out.println("Salaried Employee");
        Tampil_3061();
        System.out.println("Total Gaji: " + GajiPokok_3061);
    }
}
